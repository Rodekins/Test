package org.example;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.safari.SafariDriver;

/**
 * Hello world!
 *
 */
public class BrowserSelector
{
    protected static WebDriver driver;
    public static void openBrowser()
    {
        String browser = LoadProps.getProperty("browser");

        if (browser.equalsIgnoreCase("chrome"))
        {
            System.setProperty("webdriver.chrome.driver", "src/test/resources/browserDriver/chromedriver");
            driver = new ChromeDriver();
        }
//        else if (browser.equalsIgnoreCase("Firefox"))
//        {
//            driver = new FirefoxDriver();
//         }
        else
            {
                driver = new SafariDriver();
        }
        driver.get(LoadProps.getProperty("url"));
    }
    public void closeBrowser()
    {
        driver.quit();
    }
}
